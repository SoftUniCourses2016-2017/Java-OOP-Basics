package footballTeamGenerator;

/**
 * Created by Magdalena on 14.3.2017 г..
 */
public class CustomException extends IllegalArgumentException {

    public CustomException(String message) {
        super(message);
    }
}
