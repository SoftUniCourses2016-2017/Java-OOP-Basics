package catLady;

/**
 * Created by Magdalena on 5.3.2017 г..
 */
public class Cat {
    private String name;
    private String type;

    public Cat(String name, String type){
        this.name = name;
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }
}
