package hierarchicalInheritance;

/**
 * Created by Magdalena on 15.3.2017 г..
 */
public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
