package hierarchicalInheritance;

/**
 * Created by Magdalena on 15.3.2017 г..
 */
public class Cat extends Animal {
    public void meow(){
        System.out.println("meowing...");
    }
}
