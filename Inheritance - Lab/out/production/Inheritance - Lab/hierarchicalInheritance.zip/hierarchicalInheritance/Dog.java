package hierarchicalInheritance;

/**
 * Created by Magdalena on 15.3.2017 г..
 */
public class Dog extends Animal {
    public void bark(){
        System.out.println("barking...");
    }
}
