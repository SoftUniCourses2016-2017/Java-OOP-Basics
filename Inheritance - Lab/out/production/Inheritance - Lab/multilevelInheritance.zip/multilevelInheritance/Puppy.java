package multilevelInheritance;

/**
 * Created by Magdalena on 15.3.2017 г..
 */
public class Puppy extends Dog {
    public void weep(){
        System.out.println("weeping...");
    }
}
