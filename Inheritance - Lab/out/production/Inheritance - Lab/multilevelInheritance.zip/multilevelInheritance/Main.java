package multilevelInheritance;

/**
 * Created by Magdalena on 15.3.2017 г..
 */
public class Main {

    public static void main(String[] args) {

        Puppy puppy = new Puppy();
        puppy.eat();
        puppy.bark();
        puppy.weep();
    }
}
